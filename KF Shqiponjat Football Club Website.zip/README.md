
  # KF Shqiponjat Football Club Website

  This is a code bundle for KF Shqiponjat Football Club Website. The original project is available at https://www.figma.com/design/I0L901PNFQhPRj7WXEVWMK/KF-Shqiponjat-Football-Club-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  