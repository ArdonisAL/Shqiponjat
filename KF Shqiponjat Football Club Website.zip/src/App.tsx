import { Navigation } from "./components/Navigation";
import { HeroSection } from "./components/HeroSection";
import { AchievementCards } from "./components/AchievementCards";
import { FixturesTable } from "./components/FixturesTable";
import { CommunitySection } from "./components/CommunitySection";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main>
        <HeroSection />
        <AchievementCards />
        <FixturesTable />
        <CommunitySection />
      </main>
      <Footer />
    </div>
  );
}