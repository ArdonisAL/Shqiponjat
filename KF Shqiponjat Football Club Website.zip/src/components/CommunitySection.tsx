import { Calendar, Eye, MessageCircle, Play } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const newsArticles = [
  {
    title: "Victory Against FC Tirana Extends Winning Streak",
    excerpt: "KF Shqiponjat secured a convincing 3-1 victory over FC Tirana, marking their fourth consecutive win in the league.",
    date: "Dec 15, 2024",
    category: "Match Report",
    views: 1240,
    comments: 23
  },
  {
    title: "New Training Facility Opens Next Month",
    excerpt: "The club announces the opening of a state-of-the-art training facility that will enhance player development programs.",
    date: "Dec 12, 2024",
    category: "Club News",
    views: 856,
    comments: 12
  },
  {
    title: "Youth Academy Produces Three National Team Call-ups",
    excerpt: "Three academy graduates receive their first call-ups to the Albanian national team, highlighting our youth development success.",
    date: "Dec 10, 2024",
    category: "Youth",
    views: 2100,
    comments: 45
  }
];

const mediaHighlights = [
  {
    type: "video",
    title: "Match Highlights: KF Shqiponjat 3-1 FC Tirana",
    duration: "3:45",
    views: 5600
  },
  {
    type: "video", 
    title: "Behind the Scenes: Training Session",
    duration: "2:20",
    views: 1200
  },
  {
    type: "gallery",
    title: "Victory Celebration Photos",
    count: 24,
    views: 890
  }
];

export function CommunitySection() {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container px-4">
        <div className="mb-12">
          <h2 className="text-3xl font-bold mb-4">Community & Media</h2>
          <p className="text-muted-foreground">Stay connected with the latest news, photos, and videos from KF Shqiponjat</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* News Section */}
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold">Latest News</h3>
              <Button variant="outline" size="sm">View All News</Button>
            </div>
            
            <div className="space-y-6">
              {newsArticles.map((article, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex flex-col sm:flex-row gap-4">
                      <div className="w-full sm:w-32 h-24 bg-gradient-to-br from-red-500 to-red-700 rounded-lg flex-shrink-0 flex items-center justify-center">
                        <span className="text-white font-bold text-lg opacity-80">KFS</span>
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="secondary" className="text-xs">
                            {article.category}
                          </Badge>
                          <span className="text-muted-foreground text-xs flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {article.date}
                          </span>
                        </div>
                        
                        <h4 className="font-bold mb-2 hover:text-primary cursor-pointer">
                          {article.title}
                        </h4>
                        
                        <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                          {article.excerpt}
                        </p>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Eye className="h-3 w-3" />
                              {article.views}
                            </span>
                            <span className="flex items-center gap-1">
                              <MessageCircle className="h-3 w-3" />
                              {article.comments}
                            </span>
                          </div>
                          <Button variant="ghost" size="sm">Read More</Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Media Highlights */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold">Media Highlights</h3>
              <Button variant="outline" size="sm">View Gallery</Button>
            </div>
            
            <div className="space-y-4">
              {mediaHighlights.map((media, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-16 h-12 bg-gradient-to-br from-gray-800 to-gray-900 rounded flex items-center justify-center">
                        {media.type === "video" ? (
                          <Play className="h-5 w-5 text-white" />
                        ) : (
                          <div className="grid grid-cols-2 gap-0.5">
                            {[...Array(4)].map((_, i) => (
                              <div key={i} className="w-1.5 h-1.5 bg-white rounded-sm" />
                            ))}
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h5 className="font-medium text-sm truncate mb-1">
                          {media.title}
                        </h5>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          {media.type === "video" ? (
                            <>
                              <span>{media.duration}</span>
                              <span>•</span>
                              <span>{media.views.toLocaleString()} views</span>
                            </>
                          ) : (
                            <>
                              <span>{media.count} photos</span>
                              <span>•</span>
                              <span>{media.views} views</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Fan Social Feed */}
            <Card className="mt-8">
              <CardHeader>
                <CardTitle className="text-lg">Fan Updates</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-l-4 border-red-500 pl-4">
                  <p className="text-sm">"What a performance today! Proud to be a Shqiponja fan! 🦅"</p>
                  <p className="text-xs text-muted-foreground mt-1">@AlbanianEagle - 2h ago</p>
                </div>
                
                <div className="border-l-4 border-red-500 pl-4">
                  <p className="text-sm">"Can't wait for the next home game. The atmosphere is going to be electric!"</p>
                  <p className="text-xs text-muted-foreground mt-1">@KFSForever - 4h ago</p>
                </div>
                
                <div className="border-l-4 border-red-500 pl-4">
                  <p className="text-sm">"Our youth academy is producing amazing talent. Future looks bright! ⭐"</p>
                  <p className="text-xs text-muted-foreground mt-1">@TiranaRed - 6h ago</p>
                </div>
                
                <Button variant="outline" size="sm" className="w-full mt-4">
                  Join the Conversation
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}