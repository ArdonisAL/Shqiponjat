import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Badge } from "./ui/badge";
import { Card, CardContent } from "./ui/card";

export function HeroSection() {
  return (
    <section className="relative bg-gradient-to-r from-red-600 to-red-800 text-white py-20">
      <div className="container px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Club Crest and Info */}
          <div className="flex flex-col items-center lg:items-start text-center lg:text-left">
            <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center mb-6 shadow-xl">
              <div className="w-24 h-24 bg-red-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">KFS</span>
              </div>
            </div>
            
            <h1 className="text-4xl lg:text-6xl font-bold mb-4">KF Shqiponjat</h1>
            <p className="text-red-100 text-xl mb-2">Founded in 1978</p>
            <p className="text-red-200 text-lg mb-6 max-w-md">
              "Fluturojmë lart si shqiponja" - We soar high like the eagle
            </p>
            
            <div className="flex flex-wrap gap-2 mb-8">
              <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                Albanian First League
              </Badge>
              <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                Home: Stadiumi Kombëtar
              </Badge>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 w-full lg:w-auto">
            <Card className="bg-white/10 border-white/20 backdrop-blur">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-white">45</div>
                <div className="text-red-100 text-sm">Years Active</div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 border-white/20 backdrop-blur">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-white">3</div>
                <div className="text-red-100 text-sm">League Titles</div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 border-white/20 backdrop-blur">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-white">68%</div>
                <div className="text-red-100 text-sm">Win Rate</div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 border-white/20 backdrop-blur">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-white">142</div>
                <div className="text-red-100 text-sm">Goals Scored</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}