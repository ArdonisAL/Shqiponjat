import { Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from "lucide-react";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Club Information */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-600">
                <span className="text-sm font-bold">KF</span>
              </div>
              <div>
                <p className="font-bold text-lg">KF Shqiponjat</p>
                <p className="text-sm text-gray-400">Est. 1978</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm mb-4">
              Albania's pride, soaring high like the eagle. Home to passionate football and proud traditions since 1978.
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="p-2 border-gray-700 hover:bg-red-600 hover:border-red-600">
                <Facebook className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" className="p-2 border-gray-700 hover:bg-red-600 hover:border-red-600">
                <Twitter className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" className="p-2 border-gray-700 hover:bg-red-600 hover:border-red-600">
                <Instagram className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" className="p-2 border-gray-700 hover:bg-red-600 hover:border-red-600">
                <Youtube className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Team Squad</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Match Schedule</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">League Table</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Club History</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Youth Academy</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Merchandise</a></li>
            </ul>
          </div>

          {/* Contact Information */}
          <div>
            <h4 className="font-bold mb-4">Contact Us</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2 text-gray-400">
                <MapPin className="h-4 w-4 flex-shrink-0" />
                <span>Stadiumi Kombëtar, Tirana, Albania</span>
              </div>
              <div className="flex items-center gap-2 text-gray-400">
                <Phone className="h-4 w-4 flex-shrink-0" />
                <span>+355 4 123 4567</span>
              </div>
              <div className="flex items-center gap-2 text-gray-400">
                <Mail className="h-4 w-4 flex-shrink-0" />
                <span>info@kfshqiponjat.al</span>
              </div>
            </div>
            
            <div className="mt-6">
              <h5 className="font-medium mb-2">Stadium Info</h5>
              <p className="text-gray-400 text-sm">
                Capacity: 22,500<br />
                Built: 1946<br />
                Surface: Natural Grass
              </p>
            </div>
          </div>

          {/* Partners & Sponsors */}
          <div>
            <h4 className="font-bold mb-4">Partners & Sponsors</h4>
            <div className="space-y-4">
              <div>
                <h5 className="text-sm font-medium mb-2">Main Sponsor</h5>
                <div className="h-12 bg-white rounded flex items-center justify-center">
                  <span className="text-gray-800 font-bold">ALBANIA BANK</span>
                </div>
              </div>
              
              <div>
                <h5 className="text-sm font-medium mb-2">Kit Sponsor</h5>
                <div className="h-10 bg-gray-800 rounded flex items-center justify-center border">
                  <span className="text-white text-sm font-bold">UMBRO</span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <div className="h-8 bg-gray-800 rounded flex items-center justify-center border">
                  <span className="text-white text-xs">TELECOM</span>
                </div>
                <div className="h-8 bg-gray-800 rounded flex items-center justify-center border">
                  <span className="text-white text-xs">ENERGY AL</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-8 bg-gray-800" />

        <div className="flex flex-col md:flex-row items-center justify-between text-sm text-gray-400">
          <p>&copy; 2024 KF Shqiponjat. All rights reserved.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}