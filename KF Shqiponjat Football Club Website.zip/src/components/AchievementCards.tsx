import { Calendar, Trophy, Star, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";

export function AchievementCards() {
  return (
    <section className="py-16 bg-muted/50">
      <div className="container px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Latest Match Result */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Trophy className="h-5 w-5 text-green-600" />
                Latest Result
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-medium">KF Shqiponjat</span>
                  <Badge variant="secondary" className="bg-green-100 text-green-800">W</Badge>
                </div>
                <div className="text-center py-2">
                  <span className="text-3xl font-bold">3 - 1</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-medium">FC Tirana</span>
                  <span className="text-muted-foreground text-sm">Dec 15</span>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  View Match Details
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Fixture */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Calendar className="h-5 w-5 text-blue-600" />
                Next Fixture
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Partizani</span>
                  <Badge variant="outline">Away</Badge>
                </div>
                <div className="text-center py-2">
                  <span className="text-lg font-medium">Dec 22, 2024</span>
                  <div className="text-sm text-muted-foreground">15:00 CET</div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-medium">KF Shqiponjat</span>
                  <span className="text-muted-foreground text-sm">League</span>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  Set Reminder
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Player of the Month */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Star className="h-5 w-5 text-yellow-600" />
                Player of Month
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center text-white font-bold">
                    AR
                  </div>
                  <div>
                    <p className="font-medium">Arben Rexha</p>
                    <p className="text-sm text-muted-foreground">Forward</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Goals:</span>
                    <span className="font-medium ml-1">8</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Assists:</span>
                    <span className="font-medium ml-1">3</span>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  View Profile
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Club Honors */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Users className="h-5 w-5 text-purple-600" />
                Club Honors
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm">League Titles</span>
                  <Badge variant="secondary">3</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Cup Winners</span>
                  <Badge variant="secondary">2</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Super Cup</span>
                  <Badge variant="secondary">1</Badge>
                </div>
                <div className="pt-2">
                  <p className="text-xs text-muted-foreground">
                    Last trophy: Albanian Cup 2019
                  </p>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  Full History
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}