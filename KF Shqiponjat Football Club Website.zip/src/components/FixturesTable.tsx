import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

const fixtures = [
  { date: "Dec 22", opponent: "Partizani", venue: "Away", competition: "League", status: "upcoming" },
  { date: "Dec 28", opponent: "Vllaznia", venue: "Home", competition: "League", status: "upcoming" },
  { date: "Jan 5", opponent: "Teuta", venue: "Away", competition: "Cup", status: "upcoming" },
];

const results = [
  { date: "Dec 15", opponent: "FC Tirana", venue: "Home", score: "3-1", result: "W", competition: "League" },
  { date: "Dec 8", opponent: "Kukësi", venue: "Away", score: "1-2", result: "L", competition: "League" },
  { date: "Dec 1", opponent: "Laçi", venue: "Home", score: "2-0", result: "W", competition: "League" },
  { date: "Nov 24", opponent: "Skënderbeu", venue: "Away", score: "0-0", result: "D", competition: "League" },
  { date: "Nov 17", opponent: "Dinamo", venue: "Home", score: "4-1", result: "W", competition: "League" },
];

const standings = [
  { position: 1, team: "Partizani", played: 16, won: 12, drawn: 3, lost: 1, gf: 34, ga: 12, points: 39 },
  { position: 2, team: "KF Shqiponjat", played: 16, won: 10, drawn: 4, lost: 2, gf: 28, ga: 14, points: 34 },
  { position: 3, team: "Vllaznia", played: 16, won: 9, drawn: 5, lost: 2, gf: 25, ga: 13, points: 32 },
  { position: 4, team: "FC Tirana", played: 16, won: 8, drawn: 6, lost: 2, gf: 22, ga: 12, points: 30 },
  { position: 5, team: "Teuta", played: 16, won: 7, drawn: 4, lost: 5, gf: 19, ga: 18, points: 25 },
];

export function FixturesTable() {
  const [seasonFilter, setSeasonFilter] = useState("2024-25");
  const [competitionFilter, setCompetitionFilter] = useState("all");

  const getResultBadge = (result: string) => {
    switch (result) {
      case "W":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">W</Badge>;
      case "L":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">L</Badge>;
      case "D":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">D</Badge>;
      default:
        return null;
    }
  };

  return (
    <section className="py-16">
      <div className="container px-4">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-4">Team & Season Performance</h2>
          <div className="flex flex-col sm:flex-row gap-4">
            <Select value={seasonFilter} onValueChange={setSeasonFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select season" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2024-25">2024-25</SelectItem>
                <SelectItem value="2023-24">2023-24</SelectItem>
                <SelectItem value="2022-23">2022-23</SelectItem>
              </SelectContent>
            </Select>

            <Select value={competitionFilter} onValueChange={setCompetitionFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Competition" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Competitions</SelectItem>
                <SelectItem value="league">League</SelectItem>
                <SelectItem value="cup">Cup</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs defaultValue="fixtures" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="fixtures">Upcoming Fixtures</TabsTrigger>
            <TabsTrigger value="results">Recent Results</TabsTrigger>
            <TabsTrigger value="standings">League Table</TabsTrigger>
          </TabsList>

          <TabsContent value="fixtures" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Upcoming Fixtures</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Opponent</TableHead>
                      <TableHead>Venue</TableHead>
                      <TableHead>Competition</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {fixtures.map((fixture, index) => (
                      <TableRow key={index}>
                        <TableCell>{fixture.date}</TableCell>
                        <TableCell className="font-medium">{fixture.opponent}</TableCell>
                        <TableCell>
                          <Badge variant={fixture.venue === "Home" ? "default" : "secondary"}>
                            {fixture.venue}
                          </Badge>
                        </TableCell>
                        <TableCell>{fixture.competition}</TableCell>
                        <TableCell>
                          <Button variant="outline" size="sm">Preview</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="results" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Results</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Opponent</TableHead>
                      <TableHead>Venue</TableHead>
                      <TableHead>Score</TableHead>
                      <TableHead>Result</TableHead>
                      <TableHead>Competition</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {results.map((result, index) => (
                      <TableRow key={index}>
                        <TableCell>{result.date}</TableCell>
                        <TableCell className="font-medium">{result.opponent}</TableCell>
                        <TableCell>
                          <Badge variant={result.venue === "Home" ? "default" : "secondary"}>
                            {result.venue}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium">{result.score}</TableCell>
                        <TableCell>{getResultBadge(result.result)}</TableCell>
                        <TableCell>{result.competition}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="standings" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Albanian First League - 2024/25</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">Pos</TableHead>
                      <TableHead>Team</TableHead>
                      <TableHead className="text-center">P</TableHead>
                      <TableHead className="text-center">W</TableHead>
                      <TableHead className="text-center">D</TableHead>
                      <TableHead className="text-center">L</TableHead>
                      <TableHead className="text-center">GF</TableHead>
                      <TableHead className="text-center">GA</TableHead>
                      <TableHead className="text-center">Pts</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {standings.map((team) => (
                      <TableRow key={team.position} className={team.team === "KF Shqiponjat" ? "bg-red-50" : ""}>
                        <TableCell className="font-medium">{team.position}</TableCell>
                        <TableCell className="font-medium">{team.team}</TableCell>
                        <TableCell className="text-center">{team.played}</TableCell>
                        <TableCell className="text-center">{team.won}</TableCell>
                        <TableCell className="text-center">{team.drawn}</TableCell>
                        <TableCell className="text-center">{team.lost}</TableCell>
                        <TableCell className="text-center">{team.gf}</TableCell>
                        <TableCell className="text-center">{team.ga}</TableCell>
                        <TableCell className="text-center font-bold">{team.points}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}